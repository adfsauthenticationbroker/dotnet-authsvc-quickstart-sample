﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Web;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Xml;

//using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Options;

/*
using System;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Helpers;
*/

using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
//using System.IdentityModel.Tokens;

namespace ClaimAppDemo01.Controllers
{
    public class HomeController : Controller
    {

		public static string Base64Encode(string plainText) {
		  var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
		  return System.Convert.ToBase64String(plainTextBytes);
		}

		public static string Base64Decode(string base64EncodedData) {
		  var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
		  return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
		}

		private static Random random = new Random();
		public static string RandomString(int length)
		{
			const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
			return new string(Enumerable.Repeat(chars, length)
			  .Select(s => s[random.Next(s.Length)]).ToArray());
		}

		public static string formQueryString()
		{
			string state = RandomString(20); // your application state
			string nonce = DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss") + "." + state; // date time in GMT+8 (timezone)
			string returnUri = "http://localhost:8080/"; // your return url
			string tenantId = "f98188a6-88cb-4663-a2b4-46e4335969dc"; // tenant id
			string url = "https://mha_aws_auth_adfs_nprd.htd.gov.sg:8111/api/users/login"; // auth svc url

			string urlString = url + "?tenantid=" + Base64Encode(tenantId) + "&returnuri=" + Base64Encode(returnUri) + "&nonce=" + Base64Encode(nonce) + "&state=" + Base64Encode(state);
			return urlString;	
		}


        /*
        static string key = "401b09eab3c013d4ca54922bb802bec8fd5318192b0a75f201d8b3727429090fb337591abd3e44453b954555b7a0812e1081c39b740293f765eae731f5a65ed1";

        private static bool ValidateToken(string authToken)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var validationParameters = GetValidationParameters();

            SecurityToken validatedToken;
            IPrincipal principal = tokenHandler.ValidateToken(authToken, validationParameters, out validatedToken);
            return true;
        }

        private static TokenValidationParameters GetValidationParameters()
        {
            return new TokenValidationParameters()
            {
                ValidateLifetime = false, // Because there is no expiration in the generated token
                ValidateAudience = false, // Because there is no audiance in the generated token
                ValidateIssuer = false,   // Because there is no issuer in the generated token
                //ValidIssuer = "Sample",
                //ValidAudience = "Sample",
                ClockSkew = TimeSpan.Zero,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)) // The same key as the one that generate the token
            };
        }

        */

        
		public bool ValidateJwtToken(string token)
		{
			var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken validatedToken;

            var key = Encoding.ASCII.GetBytes("[SECRET USED TO SIGN AND VERIFY JWT TOKENS, IT CAN BE ANY STRING]");
			try
			{
				tokenHandler.ValidateToken(token, new TokenValidationParameters
				{
					ValidateIssuerSigningKey = true,
					IssuerSigningKey = new SymmetricSecurityKey(key),
					ValidateIssuer = false,
					ValidateAudience = false,
					// set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
					ClockSkew = TimeSpan.Zero
				}, out validatedToken);

				var jwtToken = (JwtSecurityToken)validatedToken;
				//var accountId = int.Parse(jwtToken.Claims.First(x => x.Type == "id").Value);

				// return account id from JWT token if validation successful
				return true;
			}
			catch
			{
				// return null if validation fails
                // return null;
				return false;
			}
		}
        

        public static string RequestBody()
        {
            var bodyStream = new StreamReader(System.Web.HttpContext.Current.Request.InputStream);
            bodyStream.BaseStream.Seek(0, SeekOrigin.Begin);
            var bodyText = bodyStream.ReadToEnd();
            return bodyText;
        }


        public ActionResult Index()
        {
            var tenantid = "";
            var userid = "";
            var emailaddress = "";
            var givenname = "";
            var surname = "";
            var displayname = "";
            var state = "";
            var nonce = "";
            var redirecturi = "";

            string rawJwtData = Request["token"];

            if (!string.IsNullOrEmpty(rawJwtData))
            {
                if (ValidateJwtToken(rawJwtData)) // check jwt signature and expiration
                { 
                    // split out the "parts" (header, payload and signature)
                    string[] parts = rawJwtData.Split('.');
                    string headerJson = parts[0];
                    string payloadJson = parts[1];
                    string signatureJson = parts[2];

                    // Resolve Invalid length for a Base-64 char array or string
                    payloadJson = payloadJson.Replace(" ", "+");
                    int mod4 = payloadJson.Length % 4;
                    if (mod4 > 0)
                    {
                        payloadJson += new string('=', 4 - mod4);
                    }

                    byte[] data = Convert.FromBase64String(payloadJson);
                    string decodedString = Encoding.UTF8.GetString(data);

                    JObject o = JObject.Parse(decodedString);
                    tenantid = o["tenantid"].ToString();
                    userid = o["userid"].ToString();
                    emailaddress = o["emailaddress"].ToString();
                    givenname = o["givenname"].ToString();
                    surname = o["surname"].ToString();
                    displayname = o["displayname"].ToString();
                    state = o["state"].ToString();
                    nonce = o["nonce"].ToString();
                    redirecturi = o["redirecturi"].ToString();
                }
            }


            // form html

            ViewBag.Title = "Home Page - " + userid;
            if (string.IsNullOrEmpty(userid))
            {
                ViewBag.loginStatus = "Login";
            }
            else
            {
                ViewBag.loginStatus = "Logout";
                ViewBag.loginSuccessStatus = "Asp.Net - Login successfully.";
                ViewBag.loginContent = "" +
                    "{userid: '" + userid + "', " +
                    "emailaddress: '" + emailaddress + "', " +
                    " givenname: '" + givenname + "', " +
                    " surname: '" + surname + "', " +
                    " displayname: '" + displayname + "', " +
                    " tenantid: '" + tenantid + "', " +
                    " nonce: '" + nonce + "', " +
                    " redirecturi: '" + redirecturi + "', " +
                    " state: '" + state + "'}";

                ViewBag.loginName = "- Welcome " + displayname;

            }

            return View();
        }

        /*
        public ActionResult Index()
        {
            var tenantid = "";
            var relaystate = "";
            var userid = "";
            var attributeName = "";
            var emailaddress = "";
            var givenname = "";
            var surname = "";
            var displayname = "";
            var state = "";
            var nonce = "";
            var redirecturi = "";

            var type = "JWTResponse";
            // spec says "SAMLResponse="

            if (type == "JWTResponse")
            {
                string rawJwtData = Request["token"];

                if (!string.IsNullOrEmpty(rawJwtData))
                {
                    // split out the "parts" (header, payload and signature)
                    string[] parts = rawJwtData.Split('.');
                    string headerJson = parts[0];
                    string payloadJson = parts[1];
                    string signatureJson = parts[2];

                    // Resolve Invalid length for a Base-64 char array or string
                    payloadJson = payloadJson.Replace(" ", "+");
                    int mod4 = payloadJson.Length % 4;
                    if (mod4 > 0)
                    {
                        payloadJson += new string('=', 4 - mod4);
                    }

                    byte[] data = Convert.FromBase64String(payloadJson);
                    string decodedString = Encoding.UTF8.GetString(data);

                    JObject o = JObject.Parse(decodedString);
                    tenantid = o["tenantid"].ToString();
                    userid = o["userid"].ToString();
                    emailaddress = o["emailaddress"].ToString();
                    givenname = o["givenname"].ToString();
                    surname = o["surname"].ToString();
                    displayname = o["displayname"].ToString();
                    state = o["state"].ToString();
                    nonce = o["nonce"].ToString();
                    redirecturi = o["redirecturi"].ToString();
                }

            }
            else
            {
                string rawSamlData = Request["SAMLResponse"];

                if (!string.IsNullOrEmpty(rawSamlData))
                {
                    // string rawSamlData = "PHNhbWxwOlJlc3BvbnNlIElEPSJfMGQ0ODIyZjMtZDc3MC00MGJkLWE5MzctNGI5NTg5NjcxMTc1IiBWZXJzaW9uPSIyLjAiIElzc3VlSW5zdGFudD0iMjAyMC0wOC0xNVQwMTowNjozMy4wNTFaIiBEZXN0aW5hdGlvbj0iaHR0cHM6Ly9sb2NhbGhvc3Q6MzAwMC9hZGZzL3Bvc3RSZXNwb25zZSIgQ29uc2VudD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmNvbnNlbnQ6dW5zcGVjaWZpZWQiIEluUmVzcG9uc2VUbz0iX2ZjODhjOWNkMzM3MzY1ODhkNTE2IiB4bWxuczpzYW1scD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3RvY29sIj48SXNzdWVyIHhtbG5zPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YXNzZXJ0aW9uIj5odHRwOi8vV0lOLTZQT1NRQzIwQ0pBLmNvcnAubG9jYWwuY29tL2FkZnMvc2VydmljZXMvdHJ1c3Q8L0lzc3Vlcj48c2FtbHA6U3RhdHVzPjxzYW1scDpTdGF0dXNDb2RlIFZhbHVlPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6c3RhdHVzOlN1Y2Nlc3MiIC8%2BPC9zYW1scDpTdGF0dXM%2BPEFzc2VydGlvbiBJRD0iXzdiYmNjYmQ2LTBiODUtNGMzYS05ODZmLWIwZGE5YzM0YzIyYSIgSXNzdWVJbnN0YW50PSIyMDIwLTA4LTE1VDAxOjA2OjMzLjA1MVoiIFZlcnNpb249IjIuMCIgeG1sbnM9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iPjxJc3N1ZXI%2BaHR0cDovL1dJTi02UE9TUUMyMENKQS5jb3JwLmxvY2FsLmNvbS9hZGZzL3NlcnZpY2VzL3RydXN0PC9Jc3N1ZXI%2BPGRzOlNpZ25hdHVyZSB4bWxuczpkcz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC8wOS94bWxkc2lnIyI%2BPGRzOlNpZ25lZEluZm8%2BPGRzOkNhbm9uaWNhbGl6YXRpb25NZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzEwL3htbC1leGMtYzE0biMiIC8%2BPGRzOlNpZ25hdHVyZU1ldGhvZCBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMDQveG1sZHNpZy1tb3JlI3JzYS1zaGEyNTYiIC8%2BPGRzOlJlZmVyZW5jZSBVUkk9IiNfN2JiY2NiZDYtMGI4NS00YzNhLTk4NmYtYjBkYTljMzRjMjJhIj48ZHM6VHJhbnNmb3Jtcz48ZHM6VHJhbnNmb3JtIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMC8wOS94bWxkc2lnI2VudmVsb3BlZC1zaWduYXR1cmUiIC8%2BPGRzOlRyYW5zZm9ybSBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMTAveG1sLWV4Yy1jMTRuIyIgLz48L2RzOlRyYW5zZm9ybXM%2BPGRzOkRpZ2VzdE1ldGhvZCBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMDQveG1sZW5jI3NoYTI1NiIgLz48ZHM6RGlnZXN0VmFsdWU%2BNE9lWkExOWJickp5dW5RaDdLbVM5bkdzTUdYUlIyZEFqS3Q4SSsyejZkbz08L2RzOkRpZ2VzdFZhbHVlPjwvZHM6UmVmZXJlbmNlPjwvZHM6U2lnbmVkSW5mbz48ZHM6U2lnbmF0dXJlVmFsdWU%2BSzZHYkhHTGZHMVdrd0hVRDE4eTZBclZpT3BJSlQrdXllSzRwRHdTMkVUZ2RFU1QyUHhYRDlKOEhISklScWNQWjRzcGxxV0Y4bU1HODg2RWFBRlVaNlZXREhKL25Xdll4Q0s1RlFlbHhoSTI4TmNaMFh1MlpJU3M3VWhOdkk1REhiMXZjb25KdVc1bHlRU2FSNlpqM2NXc3IxZkFRMmhESkZ0WFBzVHVDUWFRRGdjWXNrVFd1UkRCcm9WY09Xa3BjSEVWbDdCVXpGdXEyOEJYdTVMUnZpNUw5d1AvdUE2THUwMUpZRkxpdktuL2s2aHZ3NnlRR3hCb2hpT0lWdDNKK0ZreWVuMWR6WWxGSDRTWHkyNVhKQjNZcGVIeXRwV0RoOFEzb0xUSll6eVR0WjI3WFpiRlgwaGJCaW52K0VvRndBNmkzZ0NGY0tRYWV6L3QySHU3cEx3PT08L2RzOlNpZ25hdHVyZVZhbHVlPjxLZXlJbmZvIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjIj48ZHM6WDUwOURhdGE%2BPGRzOlg1MDlDZXJ0aWZpY2F0ZT5NSUlDK0RDQ0FlQ2dBd0lCQWdJUVRRaldTMHhsbmF4T2xLVDl3R3NTL2pBTkJna3Foa2lHOXcwQkFRc0ZBREE0TVRZd05BWURWUVFERXkxQlJFWlRJRk5wWjI1cGJtY2dMU0JYU1U0dE5sQlBVMUZETWpCRFNrRXVZMjl5Y0M1c2IyTmhiQzVqYjIwd0hoY05NakF3T0RFeU1qQXdNREV6V2hjTk1qRXdPREV5TWpBd01ERXpXakE0TVRZd05BWURWUVFERXkxQlJFWlRJRk5wWjI1cGJtY2dMU0JYU1U0dE5sQlBVMUZETWpCRFNrRXVZMjl5Y0M1c2IyTmhiQzVqYjIwd2dnRWlNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0SUJEd0F3Z2dFS0FvSUJBUURDSGxyQVdXcHdqMFdrTFdQdzZocVg3WjIxaEw2K3pLL1lMcitPU3l3MVdSR2dPc0YzQ0pIZjhGY0Eza3N3VzVCRmRTLzhwdk56aUZJOE41Q1JVWFo5RWJURDNTS1JFOUlJNlVOV1BXWnVzN2tKOHU0b1Jud0hidUlRVWE2ZmZFWmtVYnpheVdTekxEWSswMXMzdTVTMkdKZmkvKzNjeGRlQk9XWE4vQW91MDBsT1VaSHQwVEdiLzlOSnhGOUIrSWNjbWVXSXNITGtZZ1VSVUdpYUprVzdHclZnSDZZdHZtTmpmNnpyR1ViMGFEQmdoVEFsOFl3cHVxbzN2blAzOWg0S3FGMVRjaE56OW5wS1l6N2Znc1RYcklFdGNWeDg0SThzQXp4WGdxZWRuZW9kS0FucUJKNzZKWVYzVFpEM2RJMXh3L0s5VUNQSXJvR2NXTWFQN3FRNUFnTUJBQUV3RFFZSktvWklodmNOQVFFTEJRQURnZ0VCQUZTOUZBL0c1ZlZiZ1JzZEs2RVV4WmhWTEQ1QW00aG9Gb3lIWWduZk5acTlpaVE2YU90a0d3UUp4cFBVSlZMVUd3cGg5QXlLR3ZzdU5NZE1JU3NoMjQ5M2V5QWhFMFR2RldRSmxlc0NtRmdodVl0dDlEeUlvOU5kN3VtcXVwb00yN2IvQ2krSytDS3FhcFkzSXNXdEg5WTRQRVF6c1Q5blpxTDFId2ZvOWZpVmROL3VpS1hrTGNodTUzSUo4TnJ5L29nbDFKN1NJNG51LzhWU3JPU3kzSHhlRU9EVUJubW53Zk5rVGlRWTcwSHlkOG5CMzFBNVBrSXFrcnpIMVRYR1JRMDlTK1BDWDZnTXNJK1Erc3o5cDV4aFV2VTZSQXlSTmh4R1ZjbUxnWkhMOG5oaVdiZURRQm9yR21YdDd2WHlQRm5RUTZSMW82bitZYlplVHQwWFdVMD08L2RzOlg1MDlDZXJ0aWZpY2F0ZT48L2RzOlg1MDlEYXRhPjwvS2V5SW5mbz48L2RzOlNpZ25hdHVyZT48U3ViamVjdD48U3ViamVjdENvbmZpcm1hdGlvbiBNZXRob2Q9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpjbTpiZWFyZXIiPjxTdWJqZWN0Q29uZmlybWF0aW9uRGF0YSBJblJlc3BvbnNlVG89Il9mYzg4YzljZDMzNzM2NTg4ZDUxNiIgTm90T25PckFmdGVyPSIyMDIwLTA4LTE1VDAxOjExOjMzLjA1MVoiIFJlY2lwaWVudD0iaHR0cHM6Ly9sb2NhbGhvc3Q6MzAwMC9hZGZzL3Bvc3RSZXNwb25zZSIgLz48L1N1YmplY3RDb25maXJtYXRpb24%2BPC9TdWJqZWN0PjxDb25kaXRpb25zIE5vdEJlZm9yZT0iMjAyMC0wOC0xNVQwMTowNjozMy4wNTFaIiBOb3RPbk9yQWZ0ZXI9IjIwMjAtMDgtMTVUMDI6MDY6MzMuMDUxWiI%2BPEF1ZGllbmNlUmVzdHJpY3Rpb24%2BPEF1ZGllbmNlPmh0dHBzOi8vZXNlcnZpY2VzLXBvYy5pY2EuZ292LnNnOjMwMDEvPC9BdWRpZW5jZT48L0F1ZGllbmNlUmVzdHJpY3Rpb24%2BPC9Db25kaXRpb25zPjxBdHRyaWJ1dGVTdGF0ZW1lbnQ%2BPEF0dHJpYnV0ZSBOYW1lPSJOYW1lSUQiPjxBdHRyaWJ1dGVWYWx1ZT5BZG1pbmlzdHJhdG9yQGNvcnAubG9jYWwuY29tPC9BdHRyaWJ1dGVWYWx1ZT48L0F0dHJpYnV0ZT48L0F0dHJpYnV0ZVN0YXRlbWVudD48QXV0aG5TdGF0ZW1lbnQgQXV0aG5JbnN0YW50PSIyMDIwLTA4LTE1VDAxOjA2OjMzLjAzNVoiPjxBdXRobkNvbnRleHQ%2BPEF1dGhuQ29udGV4dENsYXNzUmVmPnVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphYzpjbGFzc2VzOlBhc3N3b3JkPC9BdXRobkNvbnRleHRDbGFzc1JlZj48L0F1dGhuQ29udGV4dD48L0F1dGhuU3RhdGVtZW50PjwvQXNzZXJ0aW9uPjwvc2FtbHA6UmVzcG9uc2U%2B";
                    // string samlAssertion = "<?xml version='1.0'?> <catalog> <book id='bk101'> <author>Gambardella, Matthew</author> <title>XML Developer$s Guide</title> <genre>Computer</genre> <price>44.95</price> <publish_date>2000-10-01</publish_date> <description>An in-depth look at creating applications with XML.</description> </book> <book id='bk102'> <author>Ralls, Kim</author> <title>Midnight Rain</title> <genre>Fantasy</genre> <price>5.95</price> <publish_date>2000-12-16</publish_date> <description>A former architect battles corporate zombies, an evil sorceress, and her own childhood to become queen of the world.</description> </book> <book id='bk103'> <author>Corets, Eva</author> <title>Maeve Ascendant</title> <genre>Fantasy</genre> <price>5.95</price> <publish_date>2000-11-17</publish_date> <description>After the collapse of a nanotechnology society in England, the young survivors lay the foundation for a new society.</description> </book> <book id='bk104'> <author>Corets, Eva</author> <title>Oberon$s Legacy</title> <genre>Fantasy</genre> <price>5.95</price> <publish_date>2001-03-10</publish_date> <description>In post-apocalypse England, the mysterious agent known only as Oberon helps to create a new life for the inhabitants of London. Sequel to Maeve Ascendant.</description> </book> <book id='bk105'> <author>Corets, Eva</author> <title>The Sundered Grail</title> <genre>Fantasy</genre> <price>5.95</price> <publish_date>2001-09-10</publish_date> <description>The two daughters of Maeve, half-sisters, battle one another for control of England. Sequel to Oberon$s Legacy.</description> </book> <book id='bk106'> <author>Randall, Cynthia</author> <title>Lover Birds</title> <genre>Romance</genre> <price>4.95</price> <publish_date>2000-09-02</publish_date> <description>When Carla meets Paul at an ornithology conference, tempers fly as feathers get ruffled.</description> </book> <book id='bk107'> <author>Thurman, Paula</author> <title>Splish Splash</title> <genre>Romance</genre> <price>4.95</price> <publish_date>2000-11-02</publish_date> <description>A deep sea diver finds true love twenty thousand leagues beneath the sea.</description> </book> <book id='bk108'> <author>Knorr, Stefan</author> <title>Creepy Crawlies</title> <genre>Horror</genre> <price>4.95</price> <publish_date>2000-12-06</publish_date> <description>An anthology of horror stories about roaches, centipedes, scorpions and other insects.</description> </book> <book id='bk109'> <author>Kress, Peter</author> <title>Paradox Lost</title> <genre>Science Fiction</genre> <price>6.95</price> <publish_date>2000-11-02</publish_date> <description>After an inadvertant trip through a Heisenberg Uncertainty Device, James Salway discovers the problems of being quantum.</description> </book> <book id='bk110'> <author>O$Brien, Tim</author> <title>Microsoft .NET: The Programming Bible</title> <genre>Computer</genre> <price>36.95</price> <publish_date>2000-12-09</publish_date> <description>Microsoft$s .NET initiative is explored in detail in this deep programmer$s reference.</description> </book> <book id='bk111'> <author>O$Brien, Tim</author> <title>MSXML3: A Comprehensive Guide</title> <genre>Computer</genre> <price>36.95</price> <publish_date>2000-12-01</publish_date> <description>The Microsoft MSXML3 parser is covered in detail, with attention to XML DOM interfaces, XSLT processing, SAX and more.</description> </book> <book id='bk112'> <author>Galos, Mike</author> <title>Visual Studio 7: A Comprehensive Guide</title> <genre>Computer</genre> <price>49.95</price> <publish_date>2001-04-16</publish_date> <description>Microsoft Visual Studio 7 is explored in depth, looking at how Visual Basic, Visual C++, C#, and ASP+ are integrated into a comprehensive development environment.</description> </book> </catalog>"; // which results in double encoding
                    if (rawSamlData.Contains('%'))
                    {
                        rawSamlData = HttpUtility.UrlDecode(rawSamlData);
                    }

                    // read the base64 encoded bytes
                    byte[] samlData = Convert.FromBase64String(rawSamlData);

                    // read back into a UTF string
                    string samlAssertion = Encoding.UTF8.GetString(samlData);


                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(samlAssertion);

                    string json = JsonConvert.SerializeXmlNode(doc);


                    JObject o = JObject.Parse(json);

                    attributeName = o["samlp:Response"]["Assertion"]["AttributeStatement"]["Attribute"][0]["@Name"].ToString();
                    userid = o["samlp:Response"]["Assertion"]["AttributeStatement"]["Attribute"][0]["AttributeValue"].ToString();
                    emailaddress = o["samlp:Response"]["Assertion"]["AttributeStatement"]["Attribute"][1]["AttributeValue"].ToString();
                    givenname = o["samlp:Response"]["Assertion"]["AttributeStatement"]["Attribute"][2]["AttributeValue"].ToString();
                    surname = o["samlp:Response"]["Assertion"]["AttributeStatement"]["Attribute"][3]["AttributeValue"].ToString();
                    displayname = o["samlp:Response"]["Assertion"]["AttributeStatement"]["Attribute"][4]["AttributeValue"].ToString();

                }

                //Console.WriteLine(json);

            }
            ViewBag.Title = "Home Page - " + userid;
            if (string.IsNullOrEmpty(userid))
            {
                ViewBag.loginStatus = "Login";
            }
            else
            {
                ViewBag.loginStatus = "Logout";
                ViewBag.loginSuccessStatus = "Asp.Net - Login successfully.";
                ViewBag.loginContent = "" +
                    "{userid: '" + userid + "', " +
                    "emailaddress: '" + emailaddress + "', " +
                    " givenname: '" + givenname + "', " +
                    " surname: '" + surname + "', " +
                    " displayname: '" + displayname + "', " +
                    " tenantid: '" + tenantid + "', " +
                    " nonce: '" + nonce + "', " +
                    " redirecturi: '" + redirecturi + "', " +
                    " state: '" + state + "'}";

                ViewBag.loginName = "- Welcome " + displayname;

            }

            return View();
        }

    */
    }
}
